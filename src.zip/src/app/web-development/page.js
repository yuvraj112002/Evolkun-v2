"use client";

import WebDevSurveyEntry from "@/components/lovable-survey/WebDevSurveyEntry";

export default function WebDevelopmentPage() {
  return <WebDevSurveyEntry />;
}
