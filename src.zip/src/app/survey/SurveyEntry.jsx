"use client";

import { SurveyProvider } from "@/context/SurveyContext";
import Survey from "@/components/survey/Survey"; // this will be whatever the main survey component is called

export default function SurveyEntry() {
  return (
    <SurveyProvider>
      <Survey />
    </SurveyProvider>
  );
}

