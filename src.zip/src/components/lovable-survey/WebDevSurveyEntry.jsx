"use client";

import { SurveyProvider } from "@/context/lovable-survey/SurveyContext";
import SurveyShell from "@/components/lovable-survey/survey/SurveyShell";


export default function WebDevSurveyEntry() {
  return (
    <SurveyProvider>
      <SurveyShell />
    </SurveyProvider>
  );
}
