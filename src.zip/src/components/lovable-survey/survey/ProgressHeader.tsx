import { motion } from 'framer-motion';

import { useSurvey } from '@/context/lovable-survey/SurveyContext';

import { ChevronLeft } from 'lucide-react';

export default function ProgressHeader() {
  const { progress, isFirst, prev, currentStep } = useSurvey();

  if (!currentStep || currentStep.type === 'summary') return null;

  const totalSections = 5;
  const currentSection = currentStep.section;

  return (
    <div className="w-full px-4 pt-4 pb-2">
      <div className="flex items-center gap-3 max-w-lg mx-auto">
        {!isFirst && (
          <button
            onClick={prev}
            className="shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            aria-label="Go back"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        )}
        <div className="flex-1 flex items-center gap-1.5">
          {Array.from({ length: totalSections }).map((_, i) => (
            <div key={i} className="flex-1 flex items-center">
              <div className="flex-1 h-1 rounded-full overflow-hidden bg-muted">
                <motion.div
                  className="h-full rounded-full bg-primary"
                  initial={{ width: '0%' }}
                  animate={{
                    width: i + 1 < currentSection ? '100%' : i + 1 === currentSection ? `${Math.max(10, progress * 100)}%` : '0%',
                  }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                />
              </div>
              <motion.div
                className={`shrink-0 w-2.5 h-2.5 rounded-full ml-1 ${
                  i + 1 <= currentSection ? 'bg-primary' : 'bg-muted'
                }`}
                animate={{ scale: i + 1 === currentSection ? [1, 1.3, 1] : 1 }}
                transition={{ duration: 0.3 }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
