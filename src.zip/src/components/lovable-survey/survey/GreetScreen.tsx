import { motion } from 'framer-motion';
import type { SurveyStep } from '@/lib/lovable-survey/surveyConfig';
import { useSurvey } from '@/context/lovable-survey/SurveyContext';

import { Sparkles } from 'lucide-react';

export default function GreetScreen({ step }: { step: SurveyStep }) {
  const { state } = useSurvey();
  const content = step.greetContent?.(state.answers);
  if (!content) return null;

  return (
    <div className="flex flex-col items-center justify-center gap-8 w-full max-w-lg mx-auto px-5 text-center min-h-[50vh]">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 20, delay: 0.1 }}
        className="greet-badge w-24 h-24 text-primary-foreground"
      >
        <motion.div animate={{ y: [0, -6, 0] }} transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}>
          <Sparkles className="w-10 h-10" />
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground leading-tight mb-3">
          {content.title}
        </h1>
        <p className="text-base text-muted-foreground leading-relaxed max-w-sm mx-auto">
          {content.subtitle}
        </p>
      </motion.div>
    </div>
  );
}
