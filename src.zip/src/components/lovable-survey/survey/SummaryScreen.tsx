import { motion } from 'framer-motion';

import { useSurvey } from '@/context/lovable-survey/SurveyContext';


import { Send, RotateCcw } from 'lucide-react';

export default function SummaryScreen() {
  const { state, activeSteps, reset } = useSurvey();
  const { answers } = state;

  const answerEntries = activeSteps
    .filter((s) => s.type !== 'greet' && s.type !== 'match' && s.type !== 'summary' && s.type !== 'end-message')
    .filter((s) => answers[s.id] !== undefined && answers[s.id] !== '')
    .map((s) => {
      let display = answers[s.id];
      if (Array.isArray(display)) {
        display = display
          .map((v: string) => s.options?.find((o) => o.id === v)?.label || v)
          .join(', ');
      } else if (s.options) {
        display = s.options.find((o) => o.id === display)?.label || display;
      }
      return { question: s.question || s.id, answer: String(display) };
    });

  const handleSubmit = () => {
    // In production, this would POST to an API
    alert('Survey submitted! 🎉\n\nIn production, this would send data to your backend.');
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-lg mx-auto px-5 pb-32">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground mb-1">Your Summary</h1>
        <p className="text-sm text-muted-foreground">Review your answers before submitting.</p>
      </motion.div>

      <div className="flex flex-col gap-3">
        {answerEntries.map((entry, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03 }}
            className="rounded-2xl border border-border bg-card p-4"
          >
            <p className="text-xs text-muted-foreground mb-1">{entry.question}</p>
            <p className="text-sm font-semibold text-foreground">{entry.answer}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col gap-3 pt-2"
      >
        <button onClick={handleSubmit} className="survey-cta flex items-center justify-center gap-2">
          <Send className="w-5 h-5" />
          Submit
        </button>
        <button
          onClick={reset}
          className="flex items-center justify-center gap-2 py-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          Start over
        </button>
      </motion.div>
    </div>
  );
}
