import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface OptionCardProps {
  icon?: string;
  label: string;
  description?: string;
  selected: boolean;
  onClick: () => void;
  index: number;
}

export default function OptionCard({ icon, label, description, selected, onClick, index }: OptionCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.04 }}
      onClick={onClick}
      className={`survey-card w-full text-left flex items-center gap-3 ${selected ? 'survey-card-selected' : ''}`}
      whileTap={{ scale: 0.97 }}
      aria-pressed={selected}
      role="option"
    >
      {icon && <span className="text-2xl shrink-0">{icon}</span>}
      <div className="flex-1 min-w-0">
        <span className="text-sm font-semibold text-foreground leading-tight">{label}</span>
        {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
      </div>
      <motion.div
        initial={false}
        animate={{ scale: selected ? 1 : 0, opacity: selected ? 1 : 0 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        className="shrink-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center"
      >
        <Check className="w-3.5 h-3.5 text-primary-foreground" />
      </motion.div>
    </motion.button>
  );
}
