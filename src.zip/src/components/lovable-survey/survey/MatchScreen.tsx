import { motion } from 'framer-motion';
import { Award, ArrowRight } from 'lucide-react';

export default function MatchScreen() {
  return (
    <div className="flex flex-col items-center justify-center gap-8 w-full max-w-lg mx-auto px-5 text-center min-h-[60vh]">
      {/* Animated ring badge */}
      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: 'spring', stiffness: 150, damping: 20, delay: 0.1 }}
        className="relative"
      >
        <div className="match-ring w-32 h-32 rounded-full p-1">
          <div className="w-full h-full rounded-full bg-card flex items-center justify-center">
            <motion.div
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            >
              <Award className="w-14 h-14 text-primary" />
            </motion.div>
          </div>
        </div>
        {/* Floating particles */}
        {[0, 1, 2, 3, 4].map((i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-primary/40"
            style={{
              top: `${20 + Math.sin(i * 1.2) * 50}%`,
              left: `${20 + Math.cos(i * 1.2) * 50}%`,
            }}
            animate={{
              y: [0, -10, 0],
              opacity: [0.4, 1, 0.4],
            }}
            transition={{
              duration: 2 + i * 0.3,
              repeat: Infinity,
              delay: i * 0.2,
            }}
          />
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="flex flex-col gap-3"
      >
        <p className="text-sm font-semibold text-primary uppercase tracking-wider">We've got your match!</p>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-foreground">Your Website Plan</h1>
        <p className="text-base text-muted-foreground max-w-sm mx-auto leading-relaxed">
          Based on your answers, we'll craft the best-fit structure, design vibe, and execution plan.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="flex items-center gap-2 text-sm text-primary font-medium"
      >
        <span>Continue to see your summary</span>
        <ArrowRight className="w-4 h-4" />
      </motion.div>
    </div>
  );
}
