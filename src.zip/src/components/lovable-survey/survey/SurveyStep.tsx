import { useSurvey } from '@/context/lovable-survey/SurveyContext';
import type { SurveyStep as StepType } from '@/lib/lovable-survey/surveyConfig';
import OptionCard from './OptionCard';
import { motion } from 'framer-motion';
import { Mic } from 'lucide-react';
import { useState, useRef, useCallback } from 'react';

function Headline({ question, highlights }: { question: string; highlights?: string[] }) {
  if (!highlights?.length) return <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground leading-tight">{question}</h1>;

  const parts: { text: string; highlight: boolean }[] = [];
  let remaining = question;

  for (const h of highlights) {
    const idx = remaining.toLowerCase().indexOf(h.toLowerCase());
    if (idx >= 0) {
      if (idx > 0) parts.push({ text: remaining.slice(0, idx), highlight: false });
      parts.push({ text: remaining.slice(idx, idx + h.length), highlight: true });
      remaining = remaining.slice(idx + h.length);
    }
  }
  if (remaining) parts.push({ text: remaining, highlight: false });
  if (parts.length === 0) parts.push({ text: question, highlight: false });

  return (
    <h1 className="text-2xl sm:text-3xl font-extrabold text-foreground leading-tight">
      {parts.map((p, i) =>
        p.highlight ? (
          <span key={i} className="survey-highlight">{p.text}</span>
        ) : (
          <span key={i}>{p.text}</span>
        )
      )}
    </h1>
  );
}

export default function SurveyStepView({ step }: { step: StepType }) {
  const { state, setAnswer, next } = useSurvey();
  const value = state.answers[step.id];

  const handleSingleSelect = (optionId: string) => {
    setAnswer(step.id, optionId);
    // Auto-advance after a brief moment for single select
    setTimeout(() => next(), 300);
  };

  const handleMultiSelect = (optionId: string) => {
    const current: string[] = Array.isArray(value) ? [...value] : [];
    const idx = current.indexOf(optionId);
    if (idx >= 0) {
      current.splice(idx, 1);
    } else if (!step.maxSelect || current.length < step.maxSelect) {
      current.push(optionId);
    }
    setAnswer(step.id, current);
  };

  // Voice-to-text for textarea
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  const toggleVoice = useCallback(() => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SR();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setAnswer(step.id, (value || '') + ' ' + transcript);
      setIsRecording(false);
    };
    recognition.onerror = () => setIsRecording(false);
    recognition.onend = () => setIsRecording(false);
    recognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
  }, [isRecording, step.id, value, setAnswer]);

  return (
    <div className="flex flex-col gap-4 w-full max-w-lg mx-auto px-5">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
      >
        <Headline question={step.question || ''} highlights={step.highlights} />
        {step.subtitle && (
          <p className="text-sm text-muted-foreground mt-2">{step.subtitle}</p>
        )}
      </motion.div>

      {/* Text input */}
      {(step.type === 'text' || step.type === 'url') && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <input
            type={step.type === 'url' ? 'url' : 'text'}
            value={value || ''}
            onChange={(e) => setAnswer(step.id, e.target.value)}
            placeholder={step.placeholder}
            className="w-full px-4 py-4 rounded-2xl border border-border bg-card text-foreground text-base font-medium placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
            autoFocus
            aria-label={step.question}
          />
        </motion.div>
      )}

      {/* Textarea */}
      {step.type === 'textarea' && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="relative">
          <textarea
            value={value || ''}
            onChange={(e) => setAnswer(step.id, e.target.value)}
            placeholder={step.placeholder}
            rows={4}
            className="w-full px-4 py-4 rounded-2xl border border-border bg-card text-foreground text-base font-medium placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-ring transition-shadow resize-none"
            aria-label={step.question}
          />
          {'webkitSpeechRecognition' in window && (
            <button
              onClick={toggleVoice}
              className={`absolute bottom-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                isRecording ? 'bg-destructive text-destructive-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'
              }`}
              aria-label={isRecording ? 'Stop recording' : 'Start voice input'}
            >
              <Mic className="w-4 h-4" />
            </button>
          )}
        </motion.div>
      )}

      {/* Single select */}
      {step.type === 'single' && (
        <div className="flex flex-col gap-2 max-h-[55vh] overflow-y-auto pr-1 -mr-1" role="listbox">
          {step.options?.map((opt, i) => (
            <OptionCard
              key={opt.id}
              icon={opt.icon}
              label={opt.label}
              description={opt.description}
              selected={value === opt.id}
              onClick={() => handleSingleSelect(opt.id)}
              index={i}
            />
          ))}
        </div>
      )}

      {/* Multi select */}
      {step.type === 'multi' && (
        <div className="flex flex-col gap-2 max-h-[55vh] overflow-y-auto pr-1 -mr-1" role="listbox" aria-multiselectable="true">
          {step.options?.map((opt, i) => (
            <OptionCard
              key={opt.id}
              icon={opt.icon}
              label={opt.label}
              description={opt.description}
              selected={Array.isArray(value) && value.includes(opt.id)}
              onClick={() => handleMultiSelect(opt.id)}
              index={i}
            />
          ))}
        </div>
      )}
    </div>
  );
}
