import { motion } from "framer-motion";
import type { SurveyStep } from "@/lib/lovable-survey/surveyConfig";
import { useSurvey } from "@/context/lovable-survey/SurveyContext";
import { Heart } from "lucide-react";

export default function EndMessage({ step }: { step: SurveyStep }) {
  const { reset } = useSurvey();
  const msg = step.endMessage;
  if (!msg) return null;

  return (
    <div className="flex flex-col items-center text-center gap-6">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className="greet-badge w-20 h-20 text-primary-foreground"
      >
        <Heart className="w-8 h-8" />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h1 className="text-2xl font-extrabold text-foreground mb-3">
          {msg.title}
        </h1>
        <p className="text-base text-muted-foreground leading-relaxed max-w-sm mx-auto">
          {msg.subtitle}
        </p>
      </motion.div>

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        onClick={reset}
        className="survey-cta max-w-xs"
      >
        Start Over
      </motion.button>
    </div>
  );
}
