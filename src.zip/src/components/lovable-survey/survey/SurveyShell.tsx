import { AnimatePresence, motion } from 'framer-motion';

import { useSurvey } from '@/context/lovable-survey/SurveyContext';

import ProgressHeader from './ProgressHeader';
import SurveyStepView from './SurveyStep';
import GreetScreen from './GreetScreen';
import MatchScreen from './MatchScreen';
import SummaryScreen from './SummaryScreen';
import EndMessage from './EndMessage';

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  center: { x: 0, opacity: 1 },
  exit: (direction: number) => ({
    x: direction > 0 ? -300 : 300,
    opacity: 0,
  }),
};

export default function SurveyShell() {
  const { currentStep, state, next, canGoNext } = useSurvey();

  if (!currentStep) return null;

  const showCTA =
    currentStep.type !== 'single' &&
    currentStep.type !== 'summary' &&
    currentStep.type !== 'end-message';

  const renderStep = () => {
    switch (currentStep.type) {
      case 'greet':
        return <GreetScreen step={currentStep} />;
      case 'match':
        return <MatchScreen />;
      case 'summary':
        return <SummaryScreen />;
      case 'end-message':
        return <EndMessage step={currentStep} />;
      default:
        return <SurveyStepView step={currentStep} />;
    }
  };

  return (
    <div className="flex flex-col min-h-[100dvh] bg-background">
      <ProgressHeader />

      <div className="flex-1 flex items-start justify-center overflow-hidden pt-6 sm:pt-12 pb-28">
        <AnimatePresence mode="wait" custom={state.direction}>
          <motion.div
            key={currentStep.id}
            custom={state.direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'spring', stiffness: 300, damping: 30, mass: 0.8 }}
            className="w-full"
          >
            {renderStep()}
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="p-6 bg-red-500 text-white">Tailwind test</div>

      {/* Sticky CTA */}
      {showCTA && (
        <div className="fixed bottom-0 left-0 right-0 p-4 pb-6 bg-gradient-to-t from-background via-background to-transparent">
          <div className="max-w-lg mx-auto">
            <motion.button
              whileTap={{ scale: 0.96 }}
              onClick={next}
              disabled={!canGoNext}
              className="survey-cta"
              aria-label="Continue to next step"
            >
              Continue
            </motion.button>
          </div>
        </div>
      )}
    </div>
  );
}
