"use client";

import React from "react";

/**
 * ✅ JITTER-FREE GRID OVERLAY
 * - No mask-image
 * - Cheap gradients only
 */
function GridOverlay() {
  return (
    <div className="pointer-events-none absolute inset-0">
      <div
        className="
          absolute inset-0
          bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),
              linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)]
          bg-[size:54px_54px]
          opacity-60
        "
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/20 to-black/80" />
    </div>
  );
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/80">
      {children}
    </span>
  );
}

function Card({ title, items }) {
  return (
    <div className="rounded-2xl border border-black/10 bg-white/70 p-5 backdrop-blur-sm">
      <p className="text-xs font-semibold tracking-[0.18em] text-black/50">
        {title}
      </p>
      <ul className="mt-3 space-y-2 text-sm text-black/70">
        {items.map((t) => (
          <li key={t} className="flex gap-2">
            <span className="mt-[6px] h-1.5 w-1.5 rounded-full bg-black/40" />
            <span>{t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/**
 * ✅ Slide 1: "Water repel" vibe (LIGHTWEIGHT)
 * No SVG filters, no blend modes.
 * Just layered radial gradients + slow transform blobs.
 */
function WaterRepelLite() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* base wash */}
      <div className="absolute inset-0 bg-slate-950" />

      {/* soft “wet highlights” */}
      <div
        className="absolute inset-0 opacity-[0.55]"
        style={{
          backgroundImage: `
            radial-gradient(circle at 18% 32%, rgba(255,255,255,.14) 0 10px, transparent 22px),
            radial-gradient(circle at 34% 60%, rgba(255,255,255,.12) 0 12px, transparent 26px),
            radial-gradient(circle at 62% 38%, rgba(255,255,255,.10) 0 11px, transparent 24px),
            radial-gradient(circle at 78% 64%, rgba(255,255,255,.10) 0 14px, transparent 28px),
            radial-gradient(circle at 52% 78%, rgba(255,255,255,.08) 0 10px, transparent 22px),
            radial-gradient(circle at 40% 20%, rgba(168,85,247,.16), transparent 55%)
          `,
        }}
      />

      {/* animated “liquid blobs” (transform only = smooth) */}
      <div className="absolute -left-28 -top-28 h-[520px] w-[520px] rounded-full bg-purple-500/14 blur-3xl will-change-transform animate-[wrA_18s_ease-in-out_infinite]" />
      <div className="absolute -right-36 top-10 h-[520px] w-[520px] rounded-full bg-fuchsia-400/10 blur-3xl will-change-transform animate-[wrB_22s_ease-in-out_infinite]" />
      <div className="absolute left-[20%] bottom-[-22%] h-[600px] w-[600px] rounded-full bg-indigo-400/10 blur-3xl will-change-transform animate-[wrC_20s_ease-in-out_infinite]" />

      {/* vignette (cheap) */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/18 to-black/75" />

      <style jsx>{`
        @keyframes wrA {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(40px,30px,0) scale(1.06); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
        @keyframes wrB {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(-50px,20px,0) scale(1.05); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
        @keyframes wrC {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(20px,-40px,0) scale(1.06); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
      `}</style>
    </div>
  );
}

/**
 * ✅ Slide 3: Trending “Aurora/Mesh” (LIGHTWEIGHT)
 * Same transform-only concept.
 */
function AuroraMeshLite() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-slate-950" />

      <div className="absolute -left-24 -top-28 h-[520px] w-[520px] rounded-full bg-purple-500/22 blur-3xl will-change-transform animate-[amA_16s_ease-in-out_infinite]" />
      <div className="absolute -right-24 top-10 h-[520px] w-[520px] rounded-full bg-fuchsia-400/16 blur-3xl will-change-transform animate-[amB_20s_ease-in-out_infinite]" />
      <div className="absolute left-[18%] bottom-[-18%] h-[620px] w-[620px] rounded-full bg-indigo-400/16 blur-3xl will-change-transform animate-[amC_18s_ease-in-out_infinite]" />

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(168,85,247,.18),transparent_52%)]" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/12 to-black/70" />

      <style jsx>{`
        @keyframes amA {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(40px,30px,0) scale(1.07); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
        @keyframes amB {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(-50px,20px,0) scale(1.06); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
        @keyframes amC {
          0% { transform: translate3d(0,0,0) scale(1); }
          50% { transform: translate3d(20px,-40px,0) scale(1.07); }
          100% { transform: translate3d(0,0,0) scale(1); }
        }
      `}</style>
    </div>
  );
}

export default function Index() {
  return (
    <main className="max-w-full">
      {/* ===================== STACK SECTION ===================== */}
      <section className="relative h-[300vh]">
        {/* ===================== SLIDE 1 ===================== */}
        <div className="sticky top-0 h-screen bg-slate-950 text-white [isolation:isolate] [contain:paint]">
          <div className="relative h-full overflow-hidden">
            {/* ✅ NEW: lightweight water repel background (no lag) */}
            <WaterRepelLite />

            {/* Keep your grid overlay if you want the same style */}
            <GridOverlay />

            <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
              <div className="max-w-3xl">
                <p className="text-xs tracking-[0.25em] text-white/50">
                  THE PROBLEM
                </p>

                <h2 className="mt-4 text-5xl font-semibold leading-tight">
                  Most ideas don't fail. <br />
                  They fail at the{" "}
                  <span className="text-purple-400">decision stage</span>.
                </h2>

                <p className="mt-6 text-white/70 leading-relaxed">
                  Platforms, features, budgets, timelines — it gets noisy fast.
                  Evolkun exists to turn uncertainty into structure.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ===================== SLIDE 2 ===================== */}
        <div className="sticky top-0 h-screen bg-gray-100 text-black [isolation:isolate] [contain:paint]">
          {/* (UNCHANGED) matte grid bg */}
          <div className="pointer-events-none absolute inset-0 opacity-35">
            <div className="absolute inset-0">
              <div
                className="
                  absolute inset-0
                  bg-[linear-gradient(to_right,#11111112_1px,transparent_1px),
                      linear-gradient(to_bottom,#11111112_1px,transparent_1px)]
                  bg-[size:54px_54px]
                  opacity-70
                "
              />
              <div className="absolute inset-0 bg-gradient-to-b from-white/0 via-white/30 to-white/90" />
            </div>
          </div>

          <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
            <div className="w-full">
              <p className="text-xs font-semibold tracking-[0.24em] text-black/50">
                THE SYSTEM
              </p>

              <div className="mt-4 grid grid-cols-1 gap-10 lg:grid-cols-2">
                <div className="flex flex-col justify-center">
                  <h2 className="text-4xl font-semibold tracking-tight leading-[115%] md:text-5xl">
                    How Evolkun{" "}
                    <span className="underline decoration-purple-500">
                      thinks
                    </span>
                  </h2>

                  <p className="mt-5 max-w-xl text-base leading-relaxed text-black/70">
                    Not vibes. Not assumptions. A structured way to translate
                    your answers into a build direction that actually makes
                    sense.
                  </p>

                  <div className="mt-7 flex flex-wrap gap-2">
                    {["Scope", "MVP", "Scale", "Performance", "Brand"].map(
                      (t) => (
                        <span
                          key={t}
                          className="rounded-full bg-black/5 px-3 py-1 text-xs text-black/60"
                        >
                          {t}
                        </span>
                      )
                    )}
                  </div>
                </div>

                <div className="relative">
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <Card
                      title="INPUT"
                      items={[
                        "Business type",
                        "Goals & audience",
                        "Content readiness",
                        "Design direction",
                      ]}
                    />
                    <Card
                      title="LOGIC"
                      items={[
                        "Scope mapping",
                        "Priority layering",
                        "Risk checks",
                        "Stack matching",
                      ]}
                    />
                    <Card
                      title="OUTPUT"
                      items={[
                        "Build blueprint",
                        "Feature roadmap",
                        "Timeline bands",
                        "Launch readiness",
                      ]}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ===================== SLIDE 3 ===================== */}
        <div className="sticky top-0 h-screen bg-slate-950 text-white [isolation:isolate] [contain:paint]">
          <div className="relative h-full overflow-hidden">
            {/* ✅ NEW: trending aurora mesh background (no lag) */}
            <AuroraMeshLite />

            {/* Keep your original overlay */}
            <GridOverlay />

            <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
              <div className="w-full">
                <p className="text-xs font-semibold tracking-[0.24em] text-white/55">
                  THE OUTCOME
                </p>

                <h2 className="mt-4 text-4xl font-semibold tracking-tight leading-[115%] md:text-5xl">
                  Clarity makes execution fast. <br />
                  Execution makes brands{" "}
                  <span className="text-purple-400">credible</span>.
                </h2>

                <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
                  <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
                    <p className="text-xs font-semibold tracking-[0.18em] text-white/55">
                      BEFORE
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {[
                        "Confused scope",
                        "Too many opinions",
                        "Overbuilding",
                        "Delayed launch",
                        "Constant rework",
                      ].map((t) => (
                        <Pill key={t}>{t}</Pill>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/8 p-6">

                    <p className="text-xs font-semibold tracking-[0.18em] text-white/55">
                      AFTER
                    </p>

                    <ul className="mt-4 space-y-3 text-sm text-white/75">
                      {[
                        "Clear scope with priorities",
                        "A roadmap you can follow",
                        "Build that scales without breaking",
                        "Launch with confidence",
                      ].map((t) => (
                        <li key={t} className="flex items-start gap-3">
                          <span className="mt-1.5 h-2 w-2 rounded-full bg-purple-400" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-8 text-xs text-white/55">
                  0% clarity → 100% blueprint
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===================== NORMAL SCROLL ===================== */}
      
    </main>
  );
}
