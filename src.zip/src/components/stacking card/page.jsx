"use client";

import { ReactLenis } from "lenis/react";
import React from "react";

function GridOverlay() {
  return (
    <div
      className="pointer-events-none absolute inset-0
      bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),
          linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)]
      bg-[size:54px_54px]
      [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"
    />
  );
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/80">
      {children}
    </span>
  );
}

function Card({ title, items }) {
  return (
    <div className="rounded-2xl border border-black/10 bg-white/70 p-5 backdrop-blur">
      <p className="text-xs font-semibold tracking-[0.18em] text-black/50">
        {title}
      </p>
      <ul className="mt-3 space-y-2 text-sm text-black/70">
        {items.map((t) => (
          <li key={t} className="flex gap-2">
            <span className="mt-[6px] h-1.5 w-1.5 rounded-full bg-black/40" />
            <span>{t}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Index() {
  return (
    <ReactLenis
      root
      options={{
        // ✅ makes scroll less "floaty" and reduces the re-adjust feel
        duration: 0.9,
        smoothWheel: true,
        smoothTouch: false,
      }}
    >
      <main className="max-w-full">
        {/* ✅ STICKY STACK WRAPPER (3 slides => 300vh) */}
        <section className="relative h-[300vh]">
          {/* ===================== SLIDE 1 ===================== */}
          <div className="sticky top-0 h-screen bg-slate-950 text-white">
            <div className="relative h-full overflow-hidden">
              <GridOverlay />

              <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
                <div className="max-w-3xl">
                  <p className="text-xs tracking-[0.25em] text-white/50">
                    THE PROBLEM
                  </p>

                  <h2 className="mt-4 text-5xl font-semibold leading-tight">
                    Most ideas don’t fail. <br />
                    They fail at the{" "}
                    <span className="text-purple-400">decision stage</span>.
                  </h2>

                  <p className="mt-6 text-white/70 leading-relaxed">
                    Platforms, features, budgets, timelines — it gets noisy fast.
                    Evolkun exists to turn uncertainty into structure.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ===================== SLIDE 2 ===================== */}
          <div className="sticky top-0 h-screen bg-gray-100 text-black rounded-tr-2xl rounded-tl-2xl">
            {/* overlay */}
            <div className="pointer-events-none absolute inset-0 opacity-40">
              <GridOverlay />
            </div>

            <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
              <div className="w-full">
                <p className="text-xs font-semibold tracking-[0.24em] text-black/50">
                  THE SYSTEM
                </p>

                <div className="mt-4 grid grid-cols-1 gap-10 lg:grid-cols-2">
                  {/* Left */}
                  <div className="flex flex-col justify-center">
                    <h2 className="text-4xl font-semibold tracking-tight leading-[115%] md:text-5xl">
                      How Evolkun{" "}
                      <span className="underline decoration-purple-500">
                        thinks
                      </span>
                    </h2>

                    <p className="mt-5 max-w-xl text-base leading-relaxed text-black/70">
                      Not vibes. Not assumptions. A structured way to translate
                      your answers into a build direction that actually makes
                      sense.
                    </p>

                    <div className="mt-7 flex flex-wrap gap-2">
                      {["Scope", "MVP", "Scale", "Performance", "Brand"].map(
                        (t) => (
                          <span
                            key={t}
                            className="rounded-full bg-black/5 px-3 py-1 text-xs text-black/60"
                          >
                            {t}
                          </span>
                        )
                      )}
                    </div>
                  </div>

                  {/* Right */}
                  <div className="relative">
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                      <Card
                        title="INPUT"
                        items={[
                          "Business type",
                          "Goals & audience",
                          "Content readiness",
                          "Design direction",
                        ]}
                      />
                      <Card
                        title="LOGIC"
                        items={[
                          "Scope mapping",
                          "Priority layering",
                          "Risk checks",
                          "Stack matching",
                        ]}
                      />
                      <Card
                        title="OUTPUT"
                        items={[
                          "Build blueprint",
                          "Feature roadmap",
                          "Timeline bands",
                          "Launch readiness",
                        ]}
                      />
                    </div>

                    <div className="pointer-events-none absolute inset-0 hidden md:block">
                      <div className="absolute left-[33%] top-1/2 h-px w-[34%] -translate-y-1/2 bg-black/10" />
                      <div className="absolute left-[33%] top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-purple-500/70" />
                      <div className="absolute left-[67%] top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-purple-500/70" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ===================== SLIDE 3 ===================== */}
          <div className="sticky top-0 h-screen bg-slate-950 text-white">
            <GridOverlay />

            <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6">
              <div className="w-full">
                <p className="text-xs font-semibold tracking-[0.24em] text-white/55">
                  THE OUTCOME
                </p>

                <h2 className="mt-4 text-4xl font-semibold tracking-tight leading-[115%] md:text-5xl">
                  Clarity makes execution fast. <br />
                  Execution makes brands{" "}
                  <span className="text-purple-400">credible</span>.
                </h2>

                <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
                  {/* Before */}
                  <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur">
                    <p className="text-xs font-semibold tracking-[0.18em] text-white/55">
                      BEFORE
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {[
                        "Confused scope",
                        "Too many opinions",
                        "Overbuilding",
                        "Delayed launch",
                        "Constant rework",
                      ].map((t) => (
                        <Pill key={t}>{t}</Pill>
                      ))}
                    </div>
                    <p className="mt-5 text-sm text-white/65 leading-relaxed">
                      Everything feels urgent, but nothing feels clear.
                    </p>
                  </div>

                  {/* After */}
                  <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur">
                    <p className="text-xs font-semibold tracking-[0.18em] text-white/55">
                      AFTER
                    </p>

                    <ul className="mt-4 space-y-3 text-sm text-white/75">
                      {[
                        "Clear scope with priorities",
                        "A roadmap you can follow",
                        "Build that scales without breaking",
                        "Launch with confidence",
                      ].map((t) => (
                        <li key={t} className="flex items-start gap-3">
                          <span className="mt-1.5 h-2 w-2 rounded-full bg-purple-400" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="mt-6 grid grid-cols-3 gap-3">
                      {["Build Plan", "Feature Map", "Tech Direction"].map(
                        (t) => (
                          <div
                            key={t}
                            className="rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-xs text-white/75 text-center"
                          >
                            {t}
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-8 text-xs text-white/55">
                  0% clarity → 100% blueprint (visual narrative — no CTA needed)
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ✅ NEXT SECTION (normal scroll content) */}
        <section className="relative min-h-screen bg-white text-black">
          <div className="mx-auto max-w-6xl px-6 py-24">
            <h2 className="text-3xl font-semibold">Next Section</h2>
            <p className="mt-4 text-black/70">
              Put your next content here. This will now scroll smoothly after the
              sticky stack without jumping or re-adjusting.
            </p>
          </div>
        </section>
      </main>
    </ReactLenis>
  );
}
